package com.allandroidprojects.ecomsample.utility;

import java.util.ArrayList;

/**
 * Created by 06peng on 2015/6/24.
 */
public class ImageUrlUtils {
    static ArrayList<String> wishlistImageUri = new ArrayList<>();
    static ArrayList<String> cartListImageUri = new ArrayList<>();

    public static String[] getImageUrls() {
        String[] urls = new String[] {
                "https://tse2.mm.bing.net/th?id=OIP.Pe28wt61eydnyJwIq7RcKQHaHa&pid=Api&P=0",
                "https://tse4.mm.bing.net/th?id=OIP.ePvSxJs7n9cC05J7OkJsXgHaHa&pid=Api&P=0"

        };
        return urls;
    }

    public static String[] getOffersUrls() {
        String[] urls = new String[]{
                "https://tse3.mm.bing.net/th?id=OIP.hmUikDWx-98PZS4BhxVXWwHaHa&pid=Api&P=0",
                "https://tse3.mm.bing.net/th?id=OIP.8oEvS-e1KTB_avAsGDKqNAHaEo&pid=Api&P=0",
                "https://tse1.mm.bing.net/th?id=OIP.lUoDFixLLRN2K5B3OpQ_9AHaIM&pid=Api&P=0",
                "https://s1.cdn.autoevolution.com/images/news/gallery/mercedes-sewing-machine-is-a-modern-version-of-something-classic_4.jpg",
                "https://tse1.mm.bing.net/th?id=OIP.tbR6V6wEqvhy_cWMFy5WWAHaJP&pid=Api&P=0",
                "https://sociable.co/wp-content/uploads/2010/12/SDcards_2.png"

        };
        return urls;
    }

    public static String[] getHomeApplianceUrls() {
        String[] urls = new String[]{
                "https://tse1.mm.bing.net/th?id=OIP.lUoDFixLLRN2K5B3OpQ_9AHaIM&pid=Api&P=0",
                "https://ii1.pepperfry.com/media/catalog/product/s/o/1100x1210/solid-90-x-108-inch-cotton-190-tc-queen-size-duvet-cover-by-mark-home-solid-90-x-108-inch-cotton-190-u9wsna.jpg",
                "https://tse1.mm.bing.net/th?id=OIP.aVGYb3c01YZC8fsAJaDSugHaHa&pid=Api&P=0",
                "https://i5.walmartimages.com/asr/3a7ccca4-9b98-4f1c-9aa2-a7aa20d21717.c0bcb65839723b73b5551367522485dc.jpeg"

        };
        return urls;
    }

    public static String[] getElectronicsUrls() {
        String[] urls = new String[]{
                "https://www.macworld.com/wp-content/uploads/2021/03/27in-imac-2020-studio-01-100854622-orig-1.jpg",
                "https://dr3tjvhkhrb1b.cloudfront.net/592080_dca61778-d4bc-4bb3-9fa7-c7375a1ff596_1080x1350.jpg",
                "https://sociable.co/wp-content/uploads/2010/12/SDcards_2.png",
                "https://static.pexels.com/photos/213384/pexels-photo-213384-medium.jpeg"


        };
        return urls;
    }

    public static String[] getLifeStyleUrls() {
        String[] urls = new String[]{
                "https://crayon.pk/wp-content/uploads/2017/10/Beautiful-Red-Pakistani-Party-Dresses-2017.jpg",
                "https://tse4.mm.bing.net/th?id=OIP.Ig8ZQ2E36XyaBg0Zw1t7SQHaLG&pid=Api&P=0",
                "https://ae01.alicdn.com/kf/HTB1e78aNXXXXXaxXFXXq6xXFXXX2/BS704L-Black-Houndstooth-Bowtie-Men-Cotton-Party-Classic-Wedding-Self-Bow-Tie.jpg"
        };
        return urls;
    }

    public static String[] getBooksUrls() {
        String[] urls = new String[]{
                "https://cdn.notonthehighstreet.com/fs/32/5e/01cd-2912-4d07-b80d-47640ba62799/original_whatever-make-your-soul-happy-notebook-personalised.jpg",
                "https://ae01.alicdn.com/kf/HTB1ZVmAXIfrK1Rjy0Fmq6xhEXXav/2020-Cute-Kawaii-Notebook-Hook-Star-Leather-Cartoon-Lovely-Journal-Diary-Planner-for-Kids-Gift-Notepad.jpg_Q90.jpg_.webp",
                "https://tse4.mm.bing.net/th?id=OIP.wsLTs7V6nrfpII0H4Q7SGAHaFE&pid=Api&P=0",

        };
        return urls;
    }

    // Methods for Wishlist
    public void addWishlistImageUri(String wishlistImageUri) {
        this.wishlistImageUri.add(0,wishlistImageUri);
    }

    public void removeWishlistImageUri(int position) {
        this.wishlistImageUri.remove(position);
    }

    public ArrayList<String> getWishlistImageUri(){ return this.wishlistImageUri; }

    // Methods for Cart
    public void addCartListImageUri(String wishlistImageUri) {
        this.cartListImageUri.add(0,wishlistImageUri);
    }

    public void removeCartListImageUri(int position) {
        this.cartListImageUri.remove(position);
    }

    public ArrayList<String> getCartListImageUri(){ return this.cartListImageUri; }
}
