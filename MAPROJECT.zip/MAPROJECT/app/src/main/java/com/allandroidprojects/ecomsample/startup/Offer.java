package com.allandroidprojects.ecomsample.startup;



public class Offer extends SuperClass {


    public Offer()
    {

        super();
        offers.add(new Word("Bass Guitar", "Classical guitar type of chordophone, traditionally constructed from wood a", "Rs 15999.00"));
        offers.add(new Word("Study Glasses", "Peter Jones Anti-Reflective Round Unisex Sunglasses - (NA90|48|White Color Lens)", "Rs 899.00"));
        offers.add(new Word("Table Clock", "Density Collection Digital Clocks Battery Powered Led 7 Colors Changing Night Light Star Sky Digital Led", "Rs 400.00"));
        offers.add(new Word("Sewing Machine", "Brother Sewing Machine, XM2701, Lightweight Sewing Machine with 27 Stitches powered by addition", "Rs 15000.00"));
        offers.add(new Word("Mashroom Lamp", "Modernluci Wall Sconce LED Wall Light Modern Plug in Bedroom Lamp Dark Grey", "Rs 4549.00"));
        offers.add(new Word("Camera Chip", "Kodak PIXPRO Astro Zoom AZ401-BK 16MP Digital Camera with 40X Optical Zoom and", "Rs 150000.00"));



    }





}
