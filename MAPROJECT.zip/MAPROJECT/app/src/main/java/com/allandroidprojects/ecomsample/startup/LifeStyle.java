package com.allandroidprojects.ecomsample.startup;

public class LifeStyle extends SuperClass {

    public LifeStyle()
    {
        super();

        offers.add(new Word("Red Party Dress", "VETIOR Women's Long Sleeve Scoop Neck Casual Flared MidiSwing Dress", "Rs 3150.00"));
        offers.add(new Word("Spring Outdoor Dress", "Floerns Women's Summer Chiffon Sleeveless Party Dress", "Rs 1580.00"));
        offers.add(new Word("Black Bow Tie", "Mens Classic Pre-Tied Satin FormalTuxedo Bowtie Adjustable Length Large", "Rs 399.00"));
    }
}
