package com.allandroidprojects.ecomsample.startup;

public class Home extends SuperClass {

    public Home()
    {

        super();
        offers.add(new Word("Table Clock", "Asliny Rustic Floating Corner Shelves Wall Mounted, 3 Tier Wood Storage Shelf Handmade", "Rs 400.00"));
        offers.add(new Word("Double White Bed Sheet", "Regalo HideAway Double Sided Bed Rail Guard, with Reinforced Anchor Safety System pillow", "Rs 1500.00"));
        offers.add(new Word("Mountain Frame", "Abstract Mountain in Daytime Canvas Prints Wall Art Paintings Abstract Geometry Wall", "Rs 750.00"));
        offers.add(new Word("Sofa 3 pillows", "Bikuer Printed Dark Blue Sofa Cover Stretch Couch Cover Sofa Slipcovers Couch", "Rs 870.00"));
    }
}
